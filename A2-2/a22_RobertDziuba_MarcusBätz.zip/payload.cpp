#include "payload.h"

// instantiate the payload's static count
size_t Payload::count_ = 0;


